package A1;

public class Comparacao_2 {

    public String name1, name2;
	public double salario1, salario2, calc;

    public double calcMedia() {
	
     calc = (salario1 + salario2) / 2;

     return calc;

    }

		

	

}